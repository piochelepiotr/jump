##############################################################################
# EVOLIFE  www.dessalles.fr/Evolife                    Jean-Louis Dessalles  #
#            Telecom ParisTech  2014                       www.dessalles.fr  #
##############################################################################

##############################################################################
# Ants                                                                       #
##############################################################################

""" Collective foraging:
Though individual agents follow erratic paths to find food,
the collective may discover optimal paths.
"""

# In this story, 'ants' move in search for food
# In the absence of pheromone, ants move randomly for some time,
# and then head back toward the colony.
# When they find food, they return to the colony while laying down pheromone.
# If they find pheromone, ants tend to follow it.


#######     NOTE:  this is just a sketch. The programme must be completed to
#######     display appropriate behaviour



import sys
from time import sleep
import random
import AntSprite	# graphic display of ants on a 2D field
		
sys.path.append('../..')
sys.path.append('../../../..')
import Evolife.Scenarii.Parameters 
import Evolife.Tools.Tools
import Landscapes

print Evolife.Tools.Tools.boost()	# significantly accelerates python on some platforms

Gbl = Evolife.Scenarii.Parameters.Parameters('_Params.evo')	# Loading global parameter values

# two functions to convert from complex numbers into (x,y) coordinates
c2t = lambda c: (int(round(c.real)),int(round(c.imag))) # converts a complex into a couple
t2c = lambda (x,y): complex(x,y) # converts a couple into a complex



	
class Ant_Observer:
	""" Stores global variables for observation
	"""
	def __init__(self):
		self.CurrentChanges = []	# stores temporary changes
		self.StepId = 0

	def record(self, Info):
		# stores current changes
		# Info is a couple (InfoName, Position) and Position == (x,y)
		self.CurrentChanges.append(Info)

	def retrieve(self):
		CC = self.CurrentChanges
		self.CurrentChanges = []
		return CC

class LandCell:
	""" Defines what's in one location on the ground
	"""
	def __init__(self, F=0, NP=0, PP=0):
		self.Food = F
		self.NPheromone = NP # Repulsive  pheromone
		self.PPheromone = PP # Attractive Pheromone

	def __add__(self, Other):
		# redefines the '+' operation
		return LandCell(self.Food+Other.Food,
						min(self.NPheromone + Other.NPheromone, Gbl.Parameter('Saturation')),
						min(self.PPheromone + Other.PPheromone, Gbl.Parameter('Saturation')))

	def evaporate(self):
		# Pheromone evaporation should be programmed about here
		if self.NPheromone > 0:
			self.NPheromone -= Gbl.Parameter('Evaporation') # Repulsive  pheromone
			if self.NPheromone <= 0 and self.PPheromone <= 0:
				return True
		if self.PPheromone > 0:
			self.PPheromone -= Gbl.Parameter('Evaporation') # Attractive Pheromone
			if self.NPheromone <= 0 and self.PPheromone <= 0:
				return True
		return False

class FoodSource:
	""" Location where food is available
	"""
	def __init__(self, Name):
		self.Name = Name
		self.FoodAmount = 0
		self.Location = (-1,-1)
		self.Radius = 3

	def locate(self, Location = None):
		if Location:
			self.Location = Location
		return self.Location
		
	
class Landscape(Landscapes.Landscape):
	""" A 2-D grid with cells that contains food or pheromone
	"""
	def __init__(self, Size, NbFoodSources):
		Landscapes.Landscape.__init__(self, Size, CellType=LandCell)
		
		# Positioning Food Sources
		self.FoodSourceNumber = NbFoodSources
		self.FoodSources = []
		for FSn in range(self.FoodSourceNumber):
			FS = FoodSource('FS%d' % FSn)
			FS.locate((random.randint(0,Size-1),random.randint(0,Size-1)))
			self.FoodSources.append(FS)
			for Pos in self.neighbours(FS.locate(), Radius=FS.Radius):
				self.food(Pos,10)  # Cell contains 10 food units
			Observer.record((FS.Name, FS.locate()))

	def Modify(self, (x,y), Modification):
		self.Ground[x][y] += Modification   # uses addition as redefined in LandCell
		return self.Ground[x][y]

	def food(self, Pos, delta=0):
		# adds food
		return self.Modify(Pos, LandCell(delta, 0, 0)).Food
	
	def npheromone(self, Pos, delta=0):
		# adds repulsive pheromone
		if delta:
			self.ActiveCells.append(Pos)
		return self.Modify(Pos,LandCell(0, delta, 0)).NPheromone
	
	def ppheromone(self, Pos, delta=0):
		# adds attractive pheromone
		if delta:
			self.ActiveCells.append(Pos)
		return self.Modify(Pos,LandCell(0, 0, delta)).PPheromone

	def evaporation(self):
		for Pos in self.ActiveCells.list():
			if self.Ground[Pos[0]][Pos[1]].evaporate(): # no pheromone left
				# call 'erase' for updating display when there is no pheromone left
				Observer.record(('Erase',Pos)) # for ongoing display
				self.ActiveCells.remove(Pos)

	def update(self):
		# scans ground for food and pheromone - May be used for statistics
		Food = []
		NPher = []
		PPher = []
		for Row in range(self.Size):
			for Col in range(self.Size):
				Cell = self.Ground[Row][Col]
				if Cell.Food:   Food.append((Row,Col,Cell.Food))
				if Cell.NPheromone:   NPher.append((Row,Col,Cell.NPheromone))
				if Cell.PPheromone:   PPher.append((Row,Col,Cell.PPheromone))
		return (Food, NPher, PPher)
	   
	   
class Ant:
	""" Defines individual agents
	"""
	def __init__(self, IdNb, InitialPosition):
		self.IdNb = IdNb	# Identity number
		self.Colony = t2c(InitialPosition) # Location of the colony nest
		self.Position = self.Colony # Positions are complex numbers
		self.PPStock = Gbl.Parameter('PPMax') 
		self.Action = 'Move'

	def Sniff(self):
		" Looks for the next place to go "
		Pos = self.position()
		Neighbourhood = Land.neighbours(Pos,Gbl.Parameter('SniffingDistance'))
		random.shuffle(Neighbourhood) # to avoid anisotropy
		acceptable = None
		best = -Gbl.Parameter('Saturation')	# best == pheromone balance found so far
		for NewPos in Neighbourhood:
			# looking for position devoid of negative pheromon
			if NewPos == Pos: continue
			if Land.food(NewPos):
				# Food is always good to take
				acceptable = NewPos
				break
			found = Land.ppheromone(NewPos)   # attractiveness of positive pheromone
			found -= Land.npheromone(NewPos)   # repulsiveness of negative pheromone
			if found > best:			  
				acceptable = NewPos
				best = found
		return acceptable

	def returnHome(self):
		" The ant heads toward the colony "
		Direction = (self.Colony - self.Position)   # complex number operation
		Distance = abs(Direction)
		if Distance >= Gbl.Parameter('SniffingDistance'):
			Direction /= Distance
			Land.npheromone(self.position(), Gbl.Parameter('NPDeposit')) # marking current position as visited with negative pheromone
			Land.ppheromone(self.position(), self.PPStock) # marking current posiiton as interesting with positive pheromone
			self.PPStock -= Gbl.Parameter('PPDepositDecrease')
			if self.PPStock <= Gbl.Parameter('PPMin'):   self.PPStock = Gbl.Parameter('PPMin')	# always lay some amount of positive pheromone
			Observer.record(('PP',self.position())) # for ongoing display of positive pheromone
			self.Position += 2*Direction	# complex number operation
			self.Position = t2c(Land.ToricConversion(self.position()))
			if Gbl.Parameter('NPDeposit'):
				Observer.record((self.IdNb,self.position())) # for ongoing display
		else:
			# Home reached
			self.PPStock = Gbl.Parameter('PPMax') 
			self.Action = 'Move'
		
	def moves(self):
		""" Basic behavior: move by looking for neighbouring unvisited cells.
			If food is in sight, return straight back home.
			Lay down negative pheromone on visited cells.
			Lay down positive pheromone on returning home.
		"""
		if self.Action == 'BackHome':
			self.returnHome()
		else:
			NextPos = self.Sniff()
			#if random.randint(0,100) < 10:  NextPos = None
			if NextPos is None: # all neighbouring cells have been visited
				NextPos = self.Position + complex(random.randint(-1,1),random.randint(-1,1))
				NextPos = t2c(Land.ToricConversion(c2t(NextPos)))
			else:
				NextPos = t2c(NextPos)
			# Marking the old location as visited
			Land.npheromone(self.position(), Gbl.Parameter('NPDeposit'))
			Observer.record(('NP',self.position())) # for ongoing display of negative pheromone
			self.Position = NextPos
			if Land.food(self.position()):	# return when having found food
				self.Action = 'BackHome'
			Observer.record((self.IdNb,self.position())) # for ongoing display

	def position(self):
		return c2t(self.Position)
	
class Population:
	" defines the population of agents "
	
	def __init__(self, NbAgents, ColonyPosition):
		" creates a population of ant agents "
		self.Pop = [Ant('A%d' % IdNb, ColonyPosition) for IdNb in range(NbAgents)]
		self.PopSize = NbAgents
		self.Moves = 0  # counts the number of times agents have moved
				 
	def positions(self):
		" positions of all agents "
		return dict([(A.IdNb,A.position()) for A in self.Pop])
	
	def One_Decision(self):
		""" This function is repeatedly called by the simulation thread.
			One ant is randomly chosen and decides what it does
		"""
		Observer.StepId = self.Moves // self.PopSize	# One step = all ants have moved once on average
		agent = random.choice(self.Pop)
		agent.moves()
		self.Moves += 1
		return agent.IdNb	 # This value is forwared to "ReturnFromThread"


class Ant_Frame(AntSprite.Field):
	""" Graphic display
		The programme displays ongoing ant movements .
	"""

	def __init__(self, LandSize, LandWindowSize):
		""" creation of a graphic area """
		AntSprite.Field.__init__(self, LandSize, (LandWindowSize, LandWindowSize))
		self.InitGround()
		
	
	def InitGround(self):
		" creates ants on the field "
		for FS in Land.FoodSources:
			self.add_agent(FS.Name, 'Food.png', FS.locate(), permanent=True)
		Positions = Pop.positions()
		for AgentIdNb in Positions:
			self.add_agent(AgentIdNb, 'ant_sma.png', Positions[AgentIdNb])

	def change(self):
		" Actions to be performed at each cycle "
		for O in Observer.retrieve():   # Waiting information is processed
			if O[0].startswith('A'):  # agent move
				self.agent_movement(O[0], O[1], relative=False)				
			elif O[0] in ['NP', 'PP']:
				# pheromone
				self.lay_pheromone(O[1], positive=(O[0]=='PP'))
			elif O[0].startswith('FS'):
				self.agent_movement(O[0], O[1], relative=False)
			elif O[0] == 'Erase':
				self.erase(O[1])

	def RunGround(self):
		CurrentID = Observer.StepId
		# Main loop
		while True:
			Pop.One_Decision()
			if (Observer.StepId % 1) == 0 and Observer.StepId > CurrentID:
				CurrentID = Observer.StepId
				Land.evaporation()
			Status = self.cycle()
			if Status == 'Over':
				break
			elif Status == 'Pause':
				self.wait()
			   

if __name__ == "__main__":
	print __doc__

	#############################
	# Global objects			#
	#############################
	Observer = Ant_Observer()   # Observer contains statistics
	Pop = Population(Gbl.Parameter('NbAgents'), (Gbl.Parameter('LandSize')//2, Gbl.Parameter('LandSize')//2))   # Ant colony
	Land = Landscape(Gbl.Parameter('LandSize'), Gbl.Parameter('NbFoodSources'))
	Field = Ant_Frame(Gbl.Parameter('LandSize'), Gbl.Parameter('LandWindowSize'))
	Field.RunGround()
	
	

	print "Bye......."
	
##	raw_input("\n[Return]")


__author__ = 'Dessalles'
