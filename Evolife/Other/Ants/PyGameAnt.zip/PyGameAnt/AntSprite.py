#############################################################################
# Moving agents -                                                           #
# J-L. Dessalles 2011 - adapted From the pygame package ('oldalien' example)#
#############################################################################


""" Adapted from the pygame package ('oldalien' example)
	Pygame's documentation is at: http://www.pygame.org/docs/

	To be launched from the system, not from Idle !
	
"""


import pygame as PG
import random

#constants
FRAMES_PER_SEC = 10000	# high value means faster movements

#some globals for friendly access
dirtyrects = [] # list of update_rects

#first, we define some utility functions
	
def load_image(file, transparent=1):
	"loads an image, prepares it for play"
	try:
		surface = PG.image.load(file)
	except PG.error:
		raise SystemExit('Could not load image "%s" %s' %
						 (file, PG.get_error()))
	if transparent:
		corner = surface.get_at((0, 0))
		surface.set_colorkey(corner, PG.RLEACCEL)
	return surface.convert()

class Box(PG.Rect):
	" adds features to standard pygame Rect "
	def goto(self, (x,y)):
		self.left = x
		self.top = y

	def position(self):
		return (self.left, self.top)

	def physical(self, convert):
		return PG.Rect(convert((self.left, self.top)), self.size)

	
class Agent:
	"An enhanced sort of sprite class"
	def __init__(self, image, ID, pos, convert):
		self.ID = ID	# identifier
		self.image = image  # the agent's appearence
		self.rect = Box(image.get_rect())	# bounding box
		self.Position = pos # position in standard coordinates (0..RESOLUTION)
		self.rect.goto(self.Position)		
		self.convert = convert  # coordinate conversion function (from 0..RESOLUTION to physical)
		
	def update(self):
		"update the sprite state for this frame"
		pass
	
	def draw(self, screen):
		"draws the sprite into the screen"
		r = screen.blit(self.image, self.rect.physical(self.convert))
		dirtyrects.append(r)
		
	def erase(self, screen, background):
		"gets the sprite off of the screen"
		r = self.rect.physical(self.convert)
		r = screen.blit(background, r, r)
		dirtyrects.append(r)

	def move(self, screen, background, Next, relative=True):
		self.erase(screen, background)
		self.update()
		if relative:
			# 'Next' indicates relative movement
			self.Position = (self.Position[0] + Next[0], self.Position[1] + Next[1])
		else:
			self.Position = Next
		self.rect.goto(self.Position)
		self.draw(screen)
		#.clamp(SCREENRECT)
   
class Field:
	def __init__(self, Resolution, (Width, Height), BackgroundImage='grass.jpg', WTitle='Evolife - Ants'):
		# Initialize SDL components
		PG.init()
		self.Resolution = Resolution	# Number of logical pixels
		self.ScreenSize = (Width, Height)
		self.screen = PG.display.set_mode(self.ScreenSize, 0)
		self.clock = PG.time.Clock()

		# Create background
		self.background = PG.Surface(self.ScreenSize)
		self.background.fill(PG.Color('white'))
		# showing background image
		Img = load_image(BackgroundImage, 0)
		for x in range(0, self.ScreenSize[0], Img.get_width()):
			for y in range(0, self.ScreenSize[0], Img.get_height()):
				self.background.blit(Img, (x, y))
		self.originalBG = self.background.copy()	# saving default background
		self.screen.blit(self.background, (0,0))
		PG.display.set_caption(WTitle)
		PG.display.flip()

		# Agents 
		self.agents = dict()

	def add_agent(self, name, image, pos=None, permanent=False):
		" creates a new agent "
		Img = load_image(image)
		if pos == None:
			pos = (random.randint(0,self.Resolution), random.randint(0,self.Resolution))		
		self.agents[name] = Agent(Img, name, pos, self.convert)
		if permanent:
			# the agent is also drawn onto the background
			self.background.blit(Img, self.convert(pos))
			self.originalBG = self.background.copy()

	def lay_pheromone(self, pos, quantity=1, positive=True, relative=False):
		" display pheromone on the field "
		if positive:
			Color = PG.Color('green')
		else:
			Color = PG.Color('blue')
		r = Box(pos,(2,2)).physical(self.convert)
		PG.draw.rect(self.background, Color, r) 

	def erase(self, pos):
		r = Box(pos,(2,2)).physical(self.convert)
		r = self.screen.blit(self.originalBG, r, r)
		r = self.background.blit(self.originalBG, r, r)
		dirtyrects.append(r)
	
	def convert(self, (x, y)):
		""" converts standard coordinates into physical coordinates
		"""
		#return self.toric(((float(x) * self.ScreenSize[0])/self.Resolution, (float(y) * self.ScreenSize[1])/self.Resolution))
		return self.toric((x * (self.ScreenSize[0]//self.Resolution), y * (self.ScreenSize[1]//self.Resolution)))

	def toric(self, (x,y)):
		""" relocates points into the screen, as if the screen were toric
		"""
		return (x % self.ScreenSize[0], y % self.ScreenSize[1])

		
	def key_event(self):
		# Gather Events
		PG.event.pump()
		keystate = PG.key.get_pressed()
		if keystate[PG.K_ESCAPE] or PG.event.peek(PG.QUIT) \
		   or keystate[PG.K_a]: # q on French keyboard !!!
			return 'Over'
		if keystate[PG.K_SPACE]:	return 'Pause'
		if keystate[PG.K_RIGHT]:	return 'Right'
		if keystate[PG.K_LEFT]: return 'Left'
		if keystate[PG.K_UP]:   return 'Up'
		if keystate[PG.K_DOWN]: return 'Down'

	def wait(self):
		PG.event.clear(PG.KEYDOWN)
		PG.event.clear(PG.KEYUP)
		while True:
			E = PG.event.wait()
			if E.type == PG.KEYDOWN:
				break

	def agent_action(self, agentID):
		" action to be performed by agents "
		self.lay_pheromone(self.agents[agentID].Position)

	def agent_movement(self, agentID, Direction=None, relative=True):
		" defines how agents move "
		if Direction == None:
			Direction = (random.randint(-1,1), random.randint(-1,1))
		self.agents[agentID].move(self.screen, self.background, Direction, relative)

	def change(self):
		" Default actions to be performed at each cycle (to be overloaed)"
		for actorID in self.agents:
			self.agent_action(actorID)
			# Move the player
			self.agent_movement(actorID)
			self.erase((random.randint(0,self.Resolution), random.randint(0,self.Resolution)))

	def cycle(self):
		global dirtyrects
		self.clock.tick(FRAMES_PER_SEC)
		self.change()
		PG.display.update(dirtyrects)
		dirtyrects = []
		return self.key_event()

		
def Test():
	global FRAMES_PER_SEC
	FRAMES_PER_SEC = 20	# Modifying a constant !!
	F = Field(100, (640, 480))
	F.add_agent('A01', 'ant_sma.png')
	F.add_agent('A02', 'ant_sma.png')
	F.add_agent('A03', 'ant_sma.png')
	F.add_agent('A04', 'ant_sma.png')
	F.add_agent('A05', 'ant_sma.png')
	F.add_agent('A06', 'ant_sma.png')
	F.add_agent('A07', 'ant_sma.png')
   # Main loop
	while True:
		Status = F.cycle()
		if Status == 'Over':
			break
		elif Status == 'Pause':
			F.wait()

	PG.time.wait(50)
	

#if python says run, let's run!
if __name__ == '__main__':
	Test()
	


__author__ = 'Dessalles'
